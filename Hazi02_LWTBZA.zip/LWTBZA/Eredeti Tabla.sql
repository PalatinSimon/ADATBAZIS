--Egesz eredeti tábla lekérdezése
SELECT * 
FROM UGYFELTABLA;

--Lementettem a webshopbol az ugyfel tablat es beimportaltam