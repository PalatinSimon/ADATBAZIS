CREATE USER LWTBZA IDENTIFIED BY 'NagyonTitkosJelszo123';

GRANT SELECT ON UGYFELTABLA TO LWTBZA;

--Az SQLlite nem tamogatja ezt a parancsot